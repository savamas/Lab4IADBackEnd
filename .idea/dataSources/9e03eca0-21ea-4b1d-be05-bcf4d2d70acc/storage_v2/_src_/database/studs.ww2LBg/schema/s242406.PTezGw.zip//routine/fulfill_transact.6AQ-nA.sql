create function fulfill_transact()
  returns trigger
language plpgsql
as $$
DECLARE
bonusCoeff int = 0;
BEGIN
 IF EXISTS(SELECT КЛАСС FROM ТИП_ТРАНЗАКЦИИ WHERE ТИП_ТРАНЗАКЦИИ.ИД = NEW.ИД_ТИПА AND ТИП_ТРАНЗАКЦИИ.КЛАСС = 'УВЕЛИЧ')  THEN
 UPDATE ДОГОВОР SET БАЛАНС = БАЛАНС + NEW.СУММА
	WHERE ДОГОВОР.ИД = NEW.ИД_ДОГ;
 END IF;

IF EXISTS(SELECT КЛАСС FROM ТИП_ТРАНЗАКЦИИ WHERE ТИП_ТРАНЗАКЦИИ.ИД = NEW.ИД_ТИПА AND ТИП_ТРАНЗАКЦИИ.КЛАСС = 'УМЕНЬШ') THEN
 UPDATE ДОГОВОР SET БАЛАНС = БАЛАНС - NEW.СУММА
	WHERE ДОГОВОР.ИД = NEW.ИД_ДОГ;
		IF EXISTS(SELECT FROM ТИП_ТРАНЗАКЦИИ WHERE ТИП_ТРАНЗАКЦИИ.ИД = NEW.ИД_ТИПА AND ТИП_ТРАНЗАКЦИИ.НАИМ = 'ОПЛАТА_ТАРИФА')  THEN
		

		SELECT РУБ_ЗА_БОН INTO bonusCoeff FROM ПОДКЛ_ТАР INNER JOIN ТАРИФ ON (ПОДКЛ_ТАР.ИД_ТАР = ТАРИФ.ИД);

 		UPDATE ДОГОВОР SET БАЛАНС = БАЛАНС + (NEW.СУММА/bonusCoeff)
		WHERE ДОГОВОР.ИД = NEW.ИД_ДОГ;
 		END IF;
 END IF;
 RETURN NEW;
END;
$$;

alter function fulfill_transact()
  owner to s242406;

