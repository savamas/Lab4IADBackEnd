create function check_trans()
  returns trigger
language plpgsql
as $$
BEGIN
 
IF EXISTS(SELECT FROM ТИП_ТРАНЗАКЦИИ INNER JOIN ТРАНЗАКЦИЯ
 ON (ТИП_ТРАНЗАКЦИИ.ИД = ТРАНЗАКЦИЯ.ИД_ТИПА)
	WHERE (ТРАНЗАКЦИЯ.ИД = NEW.ИД) AND
	      (ТИП_ТРАНЗАКЦИИ.НАИМЕН = 'ОПЛАТА_ТАРИФА') AND
	      (ТРАНЗАКЦИЯ.ИД_ТАР IS NULL)) THEN
 
 RAISE EXCEPTION 'НЕ УКАЗАН ОПЛАЧИВАЕМЫЙ ТАРИФ';

 END IF;

 IF (NEW.ИД_ТАР IS NOT NULL) 
 THEN
 PERFORM check_tarr_active(NEW.ИД_ТАР, NEW.ИД_ДОГ, NEW.ДАТА);
 END IF;
 
 RETURN NEW;
END;
$$;

alter function check_trans()
  owner to s242406;

