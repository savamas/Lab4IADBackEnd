create function check_pack_in_tarr()
  returns trigger
language plpgsql
as $$
BEGIN
IF NOT EXISTS(SELECT FROM ПАКЕТ_УСЛ INNER JOIN ПАКЕТ_В_ТАРИФЕ
 ON (ПАКЕТ_УСЛ.ИД = ПАКЕТ_В_ТАРИФЕ.ИД_ПАК) INNER JOIN ТАРИФ
 ON (ПАКЕТ_В_ТАРИФЕ.ИД_ТАР = ТАРИФ.ИД)
 WHERE ПАКЕТ_УСЛ.ИД = NEW.ИД_ПАК_УСЛ 
 AND ТАРИФ.ИД = NEW.ИД_ТАР) THEN
 RAISE EXCEPTION 'В ТАРИФЕ НЕТ ТАКОГО ПАКЕТА';
 END IF;

 RETURN NEW;
END;
$$;

alter function check_pack_in_tarr()
  owner to s242406;

