create function check_oper_tariff()
  returns trigger
language plpgsql
as $$
BEGIN
IF EXISTS(SELECT FROM ПОДКЛ_ТАР INNER JOIN ДОГОВОР
 ON (ДОГОВОР.ИД = ПОДКЛ_ТАР.ИД_ДОГ) INNER JOIN ОПЕРАТОР
 ON (ОПЕРАТОР.ИД = ДОГОВОР.ИД_ОПЕР) INNER JOIN ТАРИФ
 ON (ОПЕРАТОР.ИД = ТАРИФ.ИД_ОПЕР)
 WHERE ПОДКЛ_ТАР.ИД_ДОГ = NEW.ИД_ДОГ) THEN
 RAISE EXCEPTION 'У ОПЕРАТОРА НЕТ ТАКОГО ТАРИФА';
 END IF;
 
 RETURN NEW;
END;
$$;

alter function check_oper_tariff()
  owner to s242406;

