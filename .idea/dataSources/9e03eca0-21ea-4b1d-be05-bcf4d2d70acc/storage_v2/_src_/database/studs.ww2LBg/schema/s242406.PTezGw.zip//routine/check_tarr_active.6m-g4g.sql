create function check_tarr_active(tarr_id integer, dogov_id integer, curr_date timestamp without time zone)
  returns void
language plpgsql
as $$
BEGIN
 
IF NOT EXISTS(SELECT FROM ТАРИФ INNER JOIN ПОДКЛ_ТАР
 ON (ТАРИФ.ИД = ПОДКЛ_ТАР.ИД_ТАР) INNER JOIN ДОГОВОР
 ON (ПОДКЛ_ТАР.ИД_ДОГ = ДОГОВОР.ИД)
 WHERE ТАРИФ.ИД = tarr_id 
 AND ДОГОВОР.ИД = dogov_id
 AND ПОДКЛ_ТАР.ДАТА_ОТКЛ IS NOT NULL
 AND curr_date >= ПОДКЛ_ТАР.ДАТА_ОТКЛ) THEN
 RAISE EXCEPTION 'ЖЕЛАЕМЫЙ ТАРИФ ОТКЛЮЧЕН';
 END IF;

END;
$$;

alter function check_tarr_active(integer, integer, timestamp)
  owner to s242406;

